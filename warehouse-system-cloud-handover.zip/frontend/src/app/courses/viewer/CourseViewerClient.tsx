'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../../context/AuthContext';
import GlassCard from '../../../components/GlassCard';
import { 
  Play, 
  FileText, 
  HelpCircle, 
  CheckCircle, 
  ChevronRight, 
  ChevronDown, 
  ArrowLeft, 
  Clock, 
  Check, 
  X,
  Award,
  Video,
  ExternalLink,
  Maximize2,
  Shield
} from 'lucide-react';
import OTPModal from '../../../components/OTPModal';
import CertificateModal, { CertificateData } from '../../../components/CertificateModal';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';

const getSecurePdfUrl = (url: string) => {
  if (!url) return '';
  const separator = url.includes('#') ? '&' : '#';
  return `${url}${separator}toolbar=0&navpanes=0&scrollbar=0`;
};

const formatYoutubeUrl = (url: string) => {
  if (!url) return '';
  if (url.includes('youtube.com/embed/')) return url;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  if (match && match[2].length === 11) {
    return `https://www.youtube.com/embed/${match[2]}`;
  }
  return url;
};

export default function CourseViewerClient() {
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const router = useRouter();
  const { api, user } = useAuth();
  
  const [course, setCourse] = useState<any>(null);
  const [activeLesson, setActiveLesson] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [lessonProgress, setLessonProgress] = useState<number[]>([]); // Array of completed lesson IDs
  const [maxTimeWatched, setMaxTimeWatched] = useState<number>(0);
  const ytPlayerRef = React.useRef<any>(null);

  // OTP Verification States (Disabled for seamless instant learning access)
  const [showOtpModal, setShowOtpModal] = useState<boolean>(false);
  const [otpVerified, setOtpVerified] = useState<boolean>(true);

  // Load YouTube script on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const windowAny = window as any;
      if (!windowAny.YT) {
        const tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        const firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);
      }
    }
  }, []);
  
  // Quiz states
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number[]>>({}); // { questionId: [selectedOptions] }
  const [quizScore, setQuizScore] = useState<any>(null); // { score, passed, earnedPoints, totalPoints }
  const [quizTimer, setQuizTimer] = useState<number>(300); // 5 minutes in seconds
  const [quizActive, setQuizActive] = useState<boolean>(false);
  const [showCertPopup, setShowCertPopup] = useState<boolean>(false);
  const [certId, setCertId] = useState<string>('');
  const [currentQuizQuestions, setCurrentQuizQuestions] = useState<any[]>([]);
  const [displayDocUrl, setDisplayDocUrl] = useState<string>('');
  const [showFullscreenDoc, setShowFullscreenDoc] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIsMobile(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
    }
  }, []);

  const timerRef = useRef<any>(null);

  const updateLessonProgress = (lessonIdToMark: number) => {
    setLessonProgress((prev) => {
      if (prev.includes(lessonIdToMark)) return prev;
      const updated = [...prev, lessonIdToMark];
      if (typeof window !== 'undefined' && user?.id && id) {
        try {
          localStorage.setItem(`swan_completed_lessons_emp_${user.id}_course_${id}`, JSON.stringify(updated));
        } catch (e) {}
      }
      return updated;
    });
  };

  const checkAwardedPointsLocal = (entityType: string, entityId: number): boolean => {
    if (typeof window === 'undefined' || !user?.id) return false;
    try {
      const stored = localStorage.getItem(`swan_awarded_points_emp_${user.id}`);
      if (stored) {
        const list: string[] = JSON.parse(stored);
        return list.includes(`${entityType}-${entityId}`);
      }
    } catch (e) {}
    return false;
  };

  const markAwardedPointsLocal = (entityType: string, entityId: number) => {
    if (typeof window === 'undefined' || !user?.id) return;
    try {
      const stored = localStorage.getItem(`swan_awarded_points_emp_${user.id}`);
      const list: string[] = stored ? JSON.parse(stored) : [];
      const key = `${entityType}-${entityId}`;
      if (!list.includes(key)) {
        list.push(key);
        localStorage.setItem(`swan_awarded_points_emp_${user.id}`, JSON.stringify(list));
      }
    } catch (e) {}
  };

  const fetchCourseData = async () => {
    try {
      const courseId = parseInt(id as string, 10);
      
      // If courseId is NaN, wait for hydration (id changes) and do not trigger load
      if (isNaN(courseId)) {
        return;
      }

      const res = await api.get(`/api/courses/${courseId}`);
      setCourse(res.data);

      // Fetch user enrollments to get certificates/progress - isolated to prevent blocking main course view
      if (user) {
        try {
          const enrollRes = await api.get(`/api/courses/enrollments/employee/${user.id}`);
          const currentEnroll = enrollRes.data.find((e: any) => e.course_id === courseId);
          
          if (currentEnroll?.status === 'completed') {
            setCertId(currentEnroll.certificate_id || 'CERT-SAF-00612');
          }
        } catch (e) {
          console.warn('Could not fetch enrollment details, using empty fallback:', e);
        }

        try {
          let initialCompleted: number[] = [];
          if (typeof window !== 'undefined') {
            const saved = localStorage.getItem(`swan_completed_lessons_emp_${user.id}_course_${courseId}`);
            if (saved) {
              try { initialCompleted = JSON.parse(saved); } catch (e) {}
            }
          }

          if (initialCompleted.length > 0) {
            setLessonProgress(initialCompleted);
          } else if (user.id === 6 && courseId === 1) {
            setLessonProgress([1, 2, 3, 4, 5]);
          } else if (user.id === 7 && courseId === 1) {
            setLessonProgress([1, 2, 3, 4, 5]);
          } else {
            setLessonProgress([]);
          }
        } catch (e) {
          console.warn('Could not set lesson progress:', e);
        }
      }

      // Set initial active lesson (first lesson of first chapter)
      if (res.data.chapters?.length > 0 && res.data.chapters[0].lessons?.length > 0) {
        setActiveLesson(res.data.chapters[0].lessons[0]);
      } else {
        setActiveLesson(null);
      }
    } catch (err) {
      console.error('API error loading course structure:', err);
      
      const courseId = parseInt(id as string, 10);
      
      // ONLY fall back to mockCourse if this is the default course ID 1 (or NaN/initial mount)
      if (courseId === 1 || isNaN(courseId)) {
        // Mock safety course with details
        const mockCourse = {
          id: 1,
          name: 'Warehouse Safety & Accident Prevention (ความปลอดภัยคลังสินค้า)',
          description: 'หลักสูตรพื้นฐานด้านความปลอดภัยคลังสินค้าและสวมใส่ชุดอุปกรณ์ป้องกันภัยส่วนบุคคล PPE',
          duration_minutes: 120,
          category: 'Safety',
          instructor: 'นรินทร์ เก่งการ',
          chapters: [
            {
              id: 1,
              title: 'บทนำและกฎความปลอดภัยทั่วไป',
              sort_order: 1,
              lessons: [
                { id: 1, title: 'ความปลอดภัยคือหัวใจหลัก', content_type: 'video', content_url: 'https://www.youtube.com/embed/5F7Jt5pUlyU', body_text: 'ยินดีต้อนรับเข้าสู่บทเรียนเรื่องมาตรการป้องกันอุบัติเหตุเบื้องต้นในคลังสินค้า', sort_order: 1 },
                { id: 2, title: 'คู่มือมาตรการป้องกันอุบัติเหตุ PDF', content_type: 'document', content_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', body_text: 'โปรดศึกษาคู่มือความปลอดภัยตามมาตรฐานกรมสวัสดิการและคุ้มครองแรงงาน', sort_order: 2 }
              ]
            },
            {
              id: 2,
              title: 'อุปกรณ์ป้องกันภัยส่วนบุคคล (PPE)',
              sort_order: 2,
              lessons: [
                { id: 3, title: 'ประเภทและการใช้งานอุปกรณ์ PPE', content_type: 'video', content_url: 'https://www.youtube.com/embed/kR66aN42mCc', body_text: 'วิดีโอแนะนำการสวมใส่หน้ากาก หมวก รองเท้า และเสื้อสะท้อนแสงอย่างถูกต้อง', sort_order: 1 },
                { id: 4, title: 'รูปภาพสรุปการแต่งกายที่ถูกต้อง', content_type: 'image', content_url: 'https://images.unsplash.com/photo-1581094288338-2314dddb7eed?w=600', body_text: 'ตัวอย่างพนักงานแต่งกายถูกต้องขณะทำงานในพื้นที่จัดเก็บสินค้าหนัก', sort_order: 2 }
              ]
            },
            {
              id: 3,
              title: 'การทำข้อสอบประเมินความปลอดภัย',
              sort_order: 3,
              lessons: [
                {
                  id: 5,
                  title: 'แบบทดสอบวัดระดับความรู้เรื่องความปลอดภัย',
                  content_type: 'quiz',
                  body_text: 'กรุณาทำข้อสอบผ่านอย่างน้อย 80% (4 ใน 5 ข้อ) เพื่อรับใบเซอร์รับรอง',
                  sort_order: 1,
                  questions: [
                    {
                      id: 1,
                      question_type: 'multiple_choice',
                      question_text: 'เมื่อเห็นสัญลักษณ์ป้ายเตือนพื้นสีเหลืองขอบดำ หมายถึงสัญลักษณ์ประเภทใด?',
                      options: ['เตือนให้ระวัง (Warning)', 'ห้ามปฏิบัติ (Prohibition)', 'ป้ายแนะนำความปลอดภัย (Information)', 'บังคับให้ต้องปฏิบัติ (Mandatory)'],
                      points: 1
                    },
                    {
                      id: 2,
                      question_type: 'true_false',
                      question_text: 'รองเท้าผ้าใบธรรมดาสามารถสวมปฏิบัติงานในเขตคลังเก็บของหนักได้ หากระมัดระวังเป็นพิเศษ',
                      options: ['ถูกต้อง', 'ไม่ถูกต้อง (ต้องใช้รองเท้าหัวเหล็กนิรภัยเท่านั้น)'],
                      points: 1
                    },
                    {
                      id: 3,
                      question_type: 'checkbox',
                      question_text: 'อุปกรณ์ชิ้นใดจัดอยู่ในประเภทเครื่องป้องกันหน้าและดวงตา? (เลือกได้มากกว่า 1 ข้อ)',
                      options: ['แว่นตานิรภัย (Safety Glasses)', 'กระบังหน้ากันสะเก็ด (Face Shield)', 'หมวกนิรภัย (Hard Hat)', 'ที่อุดหู (Earplugs)'],
                      points: 1
                    },
                    {
                      id: 4,
                      question_type: 'multiple_choice',
                      question_text: 'หากเกิดเหตุเพลิงไหม้เบื้องต้น สิ่งแรกที่พนักงานควรทำคืออะไร?',
                      options: ['ดึงอุปกรณ์สัญญาณแจ้งเหตุเพลิงไหม้ (Fire Alarm) หรือตะโกนเตือนภัย', 'วิ่งหนีออกจากคลังสินค้าไปที่ลานจอดรถทันที', 'โทรหาครอบครัวแจ้งสถานการณ์', 'พยายามขนสินค้าออกจากโกดัง'],
                      points: 1
                    },
                    {
                      id: 5,
                      question_type: 'picture',
                      question_text: 'จากภาพสัญลักษณ์ถังดับเพลิงสีแดงนี้ เหมาะสำหรับดับเพลิงประเภทใดเป็นหลัก?',
                      media_url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300',
                      options: ['Class A (ไม้, กระดาษ, พลาสติก)', 'Class D (โลหะติดไฟ)', 'Class K (น้ำมันทำอาหาร)', 'ประเภทแก๊สติดไฟเท่านั้น'],
                      points: 1
                    }
                  ]
                }
              ]
            }
          ]
        };
        setCourse(mockCourse);
        setActiveLesson(mockCourse.chapters[0].lessons[0]);
        
        if (user?.id === 6) {
          setLessonProgress([1, 2, 3, 4, 5]);
          setCertId('CERT-SAF-00612');
        } else {
          setLessonProgress([]);
        }
      } else {
        // For custom courses, set an error course structure to inform the user instead of displaying safety details
        setCourse({
          id: courseId,
          name: 'ไม่พบเนื้อหาหลักสูตร (Course Not Found)',
          description: 'ไม่สามารถโหลดวิชาเรียนนี้ได้จากเซิร์ฟเวอร์ กรุณาตรวจสอบว่ามีบทเรียนและเนื้อหาย่อยอยู่ครบในคลังบทเรียนหรือติดต่อผู้ควบคุมระบบ',
          chapters: []
        });
        setActiveLesson(null);
        setLessonProgress([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeLesson && activeLesson.content_type === 'document' && activeLesson.content_url) {
      if (activeLesson.content_url.startsWith('data:application/pdf')) {
        try {
          const arr = activeLesson.content_url.split(',');
          const mime = arr[0].match(/:(.*?);/)?.[1] || 'application/pdf';
          const bstr = atob(arr[1]);
          let n = bstr.length;
          const u8arr = new Uint8Array(n);
          while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
          }
          const blob = new Blob([u8arr], { type: mime });
          const url = URL.createObjectURL(blob);
          setDisplayDocUrl(url);
          
          return () => {
            URL.revokeObjectURL(url);
          };
        } catch (e) {
          console.error('Failed to parse Base64 PDF to blob', e);
          setDisplayDocUrl(activeLesson.content_url);
        }
      } else {
        setDisplayDocUrl(activeLesson.content_url);
      }
    } else {
      setDisplayDocUrl('');
    }
  }, [activeLesson]);

  useEffect(() => {
    fetchCourseData();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [id, user]);

  // Quiz Timer logic
  useEffect(() => {
    if (quizActive && quizTimer > 0) {
      timerRef.current = setInterval(() => {
        setQuizTimer(prev => prev - 1);
      }, 1000);
    } else if (quizTimer === 0 && quizActive) {
      handleQuizSubmit();
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [quizActive, quizTimer]);

  const handleLessonSelect = (lesson: any) => {
    setActiveLesson(lesson);
    setQuizActive(false);
    setQuizScore(null);
    setQuizAnswers({});
    setQuizTimer(300);
    setCurrentQuizQuestions([]);
    setMaxTimeWatched(0);
  };

  const handleTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const video = e.currentTarget;
    const currentTime = video.currentTime;
    if (currentTime > maxTimeWatched + 1) {
      video.currentTime = maxTimeWatched;
    } else {
      setMaxTimeWatched(Math.max(maxTimeWatched, currentTime));
    }
  };

  const handleSeeking = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const video = e.currentTarget;
    if (video.currentTime > maxTimeWatched) {
      video.currentTime = maxTimeWatched;
    }
  };

  const handleVideoEnded = async () => {
    if (!activeLesson) return;
    if (!lessonProgress.includes(activeLesson.id)) {
      try {
        await api.post(`/api/courses/lesson/${activeLesson.id}/progress`, {
          completed: true
        });
        setLessonProgress([...lessonProgress, activeLesson.id]);
        alert('ดูวิดีโอบทเรียนจบแล้ว! บันทึกความคืบหน้าการเข้าเรียนสำเร็จ');
      } catch (err) {
        setLessonProgress([...lessonProgress, activeLesson.id]);
        alert('ดูวิดีโอบทเรียนจบแล้ว (Mock)! บันทึกความคืบหน้าการเข้าเรียนสำเร็จ');
      }
    }
  };

  const extractYoutubeVideoId = (url: string) => {
    if (!url) return '';
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : '';
  };

  // YouTube player effect
  useEffect(() => {
    let checkInterval: any = null;
    if (activeLesson?.content_type === 'video' && activeLesson.content_url && (activeLesson.content_url.includes('youtube') || activeLesson.content_url.includes('youtu.be') || activeLesson.content_url.includes('embed'))) {
      const videoId = extractYoutubeVideoId(activeLesson.content_url);
      if (videoId) {
        const initPlayer = () => {
          const windowAny = window as any;
          if (!windowAny.YT || !windowAny.YT.Player) {
            setTimeout(initPlayer, 100);
            return;
          }

          if (ytPlayerRef.current) {
            try {
              ytPlayerRef.current.destroy();
            } catch (e) {}
          }

          let ytMaxWatched = 0;

          ytPlayerRef.current = new windowAny.YT.Player('youtube-player-div', {
            height: '100%',
            width: '100%',
            videoId: videoId,
            playerVars: {
              rel: 0,
              modestbranding: 1,
              controls: 1
            },
            events: {
              onStateChange: (event: any) => {
                if (event.data === windowAny.YT.PlayerState.PLAYING) {
                  if (!checkInterval) {
                    checkInterval = setInterval(() => {
                      if (ytPlayerRef.current && ytPlayerRef.current.getCurrentTime) {
                        const currentTime = ytPlayerRef.current.getCurrentTime();
                        if (currentTime > ytMaxWatched + 2) {
                          ytPlayerRef.current.seekTo(ytMaxWatched, true);
                        } else {
                          ytMaxWatched = Math.max(ytMaxWatched, currentTime);
                        }
                      }
                    }, 500);
                  }
                } else {
                  if (checkInterval) {
                    clearInterval(checkInterval);
                    checkInterval = null;
                  }
                }

                if (event.data === windowAny.YT.PlayerState.ENDED) {
                  handleVideoEnded();
                }
              }
            }
          });
        };

        initPlayer();
      }
    }

    return () => {
      if (checkInterval) {
        clearInterval(checkInterval);
      }
      if (ytPlayerRef.current) {
        try {
          ytPlayerRef.current.destroy();
        } catch (e) {}
        ytPlayerRef.current = null;
      }
    };
  }, [activeLesson]);

  // Toggle lesson complete checkmark
  const handleMarkComplete = async () => {
    if (!activeLesson) return;
    const isCompleted = lessonProgress.includes(activeLesson.id);

    try {
      await api.post(`/api/courses/lesson/${activeLesson.id}/progress`, {
        completed: !isCompleted
      });
      
      if (isCompleted) {
        setLessonProgress(lessonProgress.filter(id => id !== activeLesson.id));
      } else {
        setLessonProgress([...lessonProgress, activeLesson.id]);
      }
    } catch (err) {
      // Mock toggle
      if (isCompleted) {
        setLessonProgress(lessonProgress.filter(id => id !== activeLesson.id));
      } else {
        setLessonProgress([...lessonProgress, activeLesson.id]);
        
        // Mock certificate check (if all 5 lessons completed)
        const allMockIds = [1, 2, 3, 4, 5];
        const nextProgress = [...lessonProgress, activeLesson.id];
        const allDone = allMockIds.every(id => nextProgress.includes(id));
        if (allDone && !certId) {
          const newCert = `CERT-1-${user?.id}-${Math.floor(Math.random() * 9000 + 1000)}`;
          setCertId(newCert);
          setShowCertPopup(true);
        }
      }
    }
  };

  // Quiz interactive selections
  const handleQuizSelection = (questionId: number, optionIndex: number, isCheckbox: boolean) => {
    const current = quizAnswers[questionId] || [];
    
    if (isCheckbox) {
      if (current.includes(optionIndex)) {
        setQuizAnswers({
          ...quizAnswers,
          [questionId]: current.filter(idx => idx !== optionIndex)
        });
      } else {
        setQuizAnswers({
          ...quizAnswers,
          [questionId]: [...current, optionIndex]
        });
      }
    } else {
      setQuizAnswers({
        ...quizAnswers,
        [questionId]: [optionIndex]
      });
    }
  };

  const startQuiz = () => {
    setQuizActive(true);
    setQuizAnswers({});
    setQuizScore(null);
    setQuizTimer(300); // 5 mins
    
    if (activeLesson?.questions && activeLesson.questions.length > 0) {
      // Shuffle activeLesson.questions
      const shuffled = [...activeLesson.questions].sort(() => 0.5 - Math.random());
      // Select 50% (half of the questions, rounded up)
      const count = Math.ceil(shuffled.length / 2);
      const selected = shuffled.slice(0, count);
      setCurrentQuizQuestions(selected);
    } else {
      setCurrentQuizQuestions([]);
    }
  };

  const handleQuizSubmit = async () => {
    setQuizActive(false);
    if (timerRef.current) clearInterval(timerRef.current);

    const alreadyAwardedLocal = checkAwardedPointsLocal('lesson', activeLesson.id) || lessonProgress.includes(activeLesson.id);

    let scoreData: any = null;

    try {
      const res = await api.post(`/api/courses/lesson/${activeLesson.id}/quiz-submit`, {
        answers: quizAnswers,
        questionIds: currentQuizQuestions.map((q: any) => q.id)
      });
      if (res && res.data && typeof res.data.score === 'number') {
        scoreData = res.data;
      }
    } catch (err: any) {
      console.warn('API quiz submit failed, using client-side fallback evaluation:', err);
    }

    if (scoreData) {
      const effectiveAlreadyAwarded = scoreData.pointsAlreadyAwarded || alreadyAwardedLocal;
      scoreData.pointsAlreadyAwarded = effectiveAlreadyAwarded;
      setQuizScore(scoreData);

      if (scoreData.passed) {
        updateLessonProgress(activeLesson.id);
        
        if (effectiveAlreadyAwarded) {
          alert('คุณสอบผ่านเกณฑ์แล้ว! (หมายเหตุ: คุณจะไม่ได้รับคะแนนเพิ่มเนื่องจากเคยทำแบบทดสอบนี้ผ่านเกณฑ์แล้ว)');
        } else {
          markAwardedPointsLocal('lesson', activeLesson.id);
          alert('ยินดีด้วย! คุณสอบผ่านเกณฑ์ 80% และได้รับคะแนนสะสมเรียบร้อยแล้ว!');
        }
        
        // Show cert popup if all course requirements met
        const allLessonIds = course?.chapters ? course.chapters.flatMap((c: any) => c.lessons).map((l: any) => l.id) : [1, 2, 3, 4, 5];
        const finalProgress = [...lessonProgress, activeLesson.id];
        const allCompleted = allLessonIds.every((lid: number) => finalProgress.includes(lid));
        if (allCompleted) {
          const newCert = `CERT-${course?.id || 1}-${user?.id || 1}-${Math.floor(Math.random() * 9000 + 1000)}`;
          setCertId(newCert);
          setShowCertPopup(true);
        }
      }
    } else {
      // Offline / Fallback client-side grading
      let earned = 0;
      let total = currentQuizQuestions.length || 1;
      
      const answerKey = { 1: [0], 2: [1], 3: [0, 1], 4: [0], 5: [0], 6: [0], 7: [1], 8: [0], 9: [1] };

      currentQuizQuestions.forEach((q: any) => {
        const correct = q.correct_answers || answerKey[q.id as keyof typeof answerKey] || [0];
        const submitted = quizAnswers[q.id] || [];
        
        const correctArr = Array.isArray(correct) ? correct : [correct];
        const submittedArr = Array.isArray(submitted) ? submitted : [submitted];

        const correctNums = correctArr.map((val: any) => parseInt(val, 10));
        const submittedNums = submittedArr.map((val: any) => parseInt(val, 10));

        const isCorrect = correctNums.length === submittedNums.length && 
                          correctNums.every(val => submittedNums.includes(val));
        if (isCorrect) earned++;
      });

      const pct = Math.round((earned / total) * 100);
      const passed = pct >= 80;
      const effectiveAlreadyAwarded = alreadyAwardedLocal;

      const fallbackResult = {
        score: pct,
        passed,
        earnedPoints: earned,
        totalPoints: total,
        pointsAlreadyAwarded: effectiveAlreadyAwarded
      };

      setQuizScore(fallbackResult);

      if (passed) {
        updateLessonProgress(activeLesson.id);
        
        if (effectiveAlreadyAwarded) {
          alert('คุณสอบผ่านเกณฑ์แล้ว! (หมายเหตุ: คุณจะไม่ได้รับคะแนนเพิ่มเนื่องจากเคยทำแบบทดสอบนี้ผ่านเกณฑ์แล้ว)');
        } else {
          markAwardedPointsLocal('lesson', activeLesson.id);
          alert('ยินดีด้วย! คุณสอบผ่านเกณฑ์ 80% และได้รับคะแนนสะสมเรียบร้อยแล้ว!');
        }
        
        const mockIds = [1, 2, 3, 4, 5];
        const updated = [...lessonProgress, activeLesson.id];
        const allDone = mockIds.every(id => updated.includes(id));
        if (allDone) {
          const newCert = `CERT-${course?.id || 1}-${user?.id || 1}-${Math.floor(Math.random() * 9000 + 1000)}`;
          setCertId(newCert);
          setShowCertPopup(true);
        }
      }
    }
  };

  const getLessonIcon = (type: string) => {
    switch (type) {
      case 'video': return <Video size={16} className="text-sky-500" />;
      case 'document': return <FileText size={16} className="text-amber-500" />;
      case 'quiz': return <HelpCircle size={16} className="text-emerald-500" />;
      default: return <FileText size={16} className="text-slate-400" />;
    }
  };

  // Timer formatter
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex-grow flex items-center justify-center min-h-[400px]">
        <div className="w-10 h-10 border-4 border-slate-300 border-t-warehouse-orange rounded-full animate-spin" />
      </div>
    );
  }

  // Calculate course completion progress percentage
  const totalCourseLessons = course?.chapters.flatMap((c: any) => c.lessons) || [];
  const completedCount = totalCourseLessons.filter((l: any) => lessonProgress.includes(l.id)).length;
  const coursePercent = totalCourseLessons.length > 0 ? Math.round((completedCount / totalCourseLessons.length) * 100) : 0;

  return (
    <div className="flex flex-col gap-6 relative">
      
      {/* Top Navigation Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200/50 dark:border-white/5">
        <div className="flex items-center gap-3">
          <Link href="/courses" className="p-2 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400 transition-colors">
            <ArrowLeft size={16} />
          </Link>
          <div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-white line-clamp-1">{course?.name}</h2>
            <p className="text-xs text-slate-400 mt-0.5">ผู้สอน: {course?.instructor} • ความก้าวหน้าวิชาเรียน</p>
          </div>
        </div>

        {/* Progress Tracker */}
        <div className="flex items-center gap-4 w-full md:w-80">
          <div className="flex-1">
            <div className="flex justify-between text-[10px] font-bold mb-1">
              <span className="text-slate-400">ภาพรวมหลักสูตร</span>
              <span className="text-warehouse-orange font-mono">{coursePercent}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div className="bg-warehouse-orange h-full rounded-full transition-all duration-300" style={{ width: `${coursePercent}%` }} />
            </div>
          </div>
          {certId && (
            <button 
              onClick={() => setShowCertPopup(true)} 
              className="px-3 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-500 rounded-xl text-xs font-bold flex items-center gap-1 border border-emerald-500/20 transition-all shrink-0"
            >
              <Award size={14} />
              <span>ใบเซอร์</span>
            </button>
          )}
        </div>
      </div>

      {/* Workspace split */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Side: Chapter & Lesson Syllabus */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-extrabold text-xs text-slate-400 uppercase tracking-widest px-2">เนื้อหาบทเรียน (Syllabus)</h3>
          
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {course?.chapters.map((chapter: any) => (
              <div key={chapter.id} className="space-y-1">
                <p className="font-bold text-xs text-slate-500 dark:text-slate-300 px-2 py-1 flex items-center gap-1">
                  <ChevronDown size={14} className="text-slate-400" />
                  <span className="line-clamp-1">{chapter.title}</span>
                </p>
                <div className="space-y-0.5 pl-3 border-l border-slate-200 dark:border-white/5">
                  {chapter.lessons.map((lesson: any) => {
                    const isActive = activeLesson?.id === lesson.id;
                    const isDone = lessonProgress.includes(lesson.id);

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => handleLessonSelect(lesson)}
                        className={`w-full text-left px-3 py-2.5 rounded-xl text-xs flex items-center justify-between gap-3 transition-colors ${
                          isActive 
                            ? 'bg-warehouse-orange/10 text-warehouse-orange font-bold border border-warehouse-orange/20' 
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          {getLessonIcon(lesson.content_type)}
                          <span className="truncate">{lesson.title}</span>
                          {lesson.evaluation_points !== undefined && lesson.evaluation_points > 0 && (
                            <span className="text-[8px] font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded shrink-0 border border-emerald-500/10">
                              ★+{lesson.evaluation_points}
                            </span>
                          )}
                        </div>
                        {isDone && <CheckCircle className="text-emerald-500 shrink-0" size={14} />}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Active Content Player */}
        <div className="lg:col-span-3">
          {activeLesson ? (
            <div className="space-y-6">
              
              {/* Media Player Card */}
              {activeLesson.content_type === 'video' && activeLesson.content_url && (
                <GlassCard className="p-0 overflow-hidden shadow-lg border border-slate-200/50 dark:border-white/5">
                  <div className="relative w-full aspect-video">
                    {activeLesson.content_url.startsWith('data:video') || activeLesson.content_url.endsWith('.mp4') || (!activeLesson.content_url.includes('youtube') && !activeLesson.content_url.includes('vimeo') && !activeLesson.content_url.includes('embed')) ? (
                      <video
                        src={activeLesson.content_url}
                        controls
                        onTimeUpdate={handleTimeUpdate}
                        onSeeking={handleSeeking}
                        onEnded={handleVideoEnded}
                        className="w-full h-full object-contain bg-black"
                        controlsList="nodownload"
                      />
                    ) : (
                      activeLesson.content_url.includes('youtube') || activeLesson.content_url.includes('youtu.be') ? (
                        <div id="youtube-player-div" className="w-full h-full bg-black" />
                      ) : (
                        <iframe
                          src={formatYoutubeUrl(activeLesson.content_url)}
                          title={activeLesson.title}
                          className="w-full h-full border-none"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      )
                    )}
                  </div>
                </GlassCard>
              )}

              {activeLesson.content_type === 'document' && activeLesson.content_url && (
                <GlassCard 
                  className="min-h-[380px] md:h-[500px] flex flex-col p-0 overflow-hidden border border-slate-200/50 dark:border-white/5 select-none"
                  onContextMenu={(e) => e.preventDefault()}
                >
                  <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-200/50 dark:border-white/5 bg-slate-100/50 dark:bg-white/5">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-bold text-xs truncate">เอกสารหลักสูตร: {activeLesson.title}</span>
                      <span className="px-2 py-0.5 rounded-md text-[9px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                        อ่านออนไลน์เท่านั้น
                      </span>
                    </div>
                    <button 
                      onClick={() => setShowFullscreenDoc(true)} 
                      className="text-xs text-warehouse-orange hover:text-warehouse-orange/80 font-bold flex items-center gap-1.5 bg-warehouse-orange/10 border border-warehouse-orange/20 px-3 py-1.5 rounded-xl transition-all shrink-0"
                      title="เปิดอ่านเอกสาร PDF เต็มจอ"
                    >
                      <Maximize2 size={13} />
                      <span>เปิดอ่าน PDF เต็มจอ</span>
                    </button>
                  </div>
                  {isMobile ? (
                    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-50 dark:bg-slate-900/40 space-y-4">
                      <div className="p-4 bg-warehouse-orange/10 text-warehouse-orange rounded-full">
                        <FileText size={40} />
                      </div>
                      <div className="space-y-1.5 max-w-sm">
                        <h4 className="font-bold text-slate-800 dark:text-white text-xs">เอกสารสำหรับเรียนรู้ออนไลน์</h4>
                        <p className="text-[10px] text-slate-400">ระบบป้องกันการดาวน์โหลดเอกสาร ท่านสามารถเปิดอ่านเอกสารแบบเต็มจอในระบบได้ทันที</p>
                      </div>
                      <button 
                        onClick={() => setShowFullscreenDoc(true)} 
                        className="px-5 py-2.5 bg-warehouse-orange hover:bg-warehouse-orange/95 text-white rounded-xl font-bold text-[10px] shadow-md shadow-warehouse-orange/15 transition-all flex items-center gap-2"
                      >
                        <Maximize2 size={13} />
                        <span>เปิดอ่านไฟล์เอกสาร PDF (Fullscreen Reader)</span>
                      </button>
                    </div>
                  ) : (
                    <iframe 
                      src={getSecurePdfUrl(displayDocUrl)} 
                      className="w-full flex-1 border-none bg-slate-900" 
                      title={activeLesson.title}
                    />
                  )}
                </GlassCard>
              )}

              {activeLesson.content_type === 'image' && activeLesson.content_url && (
                <GlassCard className="p-0 overflow-hidden border border-slate-200/50 dark:border-white/5">
                  <img src={activeLesson.content_url} alt={activeLesson.title} className="w-full max-h-[350px] object-cover" />
                </GlassCard>
              )}

              {/* Quiz content wrapper */}
              {activeLesson.content_type === 'quiz' && (
                <GlassCard className="border border-slate-200/50 dark:border-white/5">
                  {!quizActive && !quizScore ? (
                    <div className="text-center py-10 max-w-sm mx-auto space-y-6">
                      <HelpCircle size={48} className="mx-auto text-warehouse-orange animate-pulse" />
                      <div>
                        <h4 className="font-bold text-base text-slate-800 dark:text-white">{activeLesson.title}</h4>
                        <p className="text-slate-400 text-xs mt-2">{activeLesson.body_text}</p>
                      </div>
                      <button 
                        onClick={startQuiz}
                        className="px-6 py-3 bg-warehouse-orange hover:bg-warehouse-orange/95 text-white rounded-xl font-bold text-xs shadow-md shadow-warehouse-orange/15 transition-all"
                      >
                        เริ่มทำข้อสอบ (Start Quiz)
                      </button>
                    </div>
                  ) : quizActive ? (
                    <div className="space-y-6">
                      {/* Timer & header */}
                      <div className="flex items-center justify-between pb-4 border-b border-slate-200/50 dark:border-white/5">
                        <span className="font-bold text-xs text-slate-700 dark:text-slate-200">แบบทดสอบวัดระดับ</span>
                        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 border border-rose-500/20 text-xs font-mono font-bold">
                          <Clock size={14} />
                          <span>เวลาที่เหลือ: {formatTime(quizTimer)}</span>
                        </div>
                      </div>

                      {/* Question loop */}
                      <div className="space-y-6 max-h-[400px] overflow-y-auto pr-1">
                        {currentQuizQuestions?.map((q: any, qIdx: number) => {
                          const isCheckbox = q.question_type === 'checkbox';
                          const answers = quizAnswers[q.id] || [];

                          return (
                            <div key={q.id} className="space-y-3.5">
                              <p className="font-bold text-xs text-slate-700 dark:text-slate-200">
                                {qIdx + 1}. {q.question_text}
                              </p>
                              {q.media_url && (
                                <img src={q.media_url} alt="Question media" className="w-full max-w-xs rounded-xl object-cover border border-slate-200/50 dark:border-white/5" />
                              )}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                {(q.shuffledOptions || q.options.map((opt: string, idx: number) => ({ text: opt, originalIndex: idx }))).map((opt: any) => {
                                  const isSelected = answers.includes(opt.originalIndex);

                                  return (
                                    <button
                                      key={opt.originalIndex}
                                      type="button"
                                      onClick={() => handleQuizSelection(q.id, opt.originalIndex, isCheckbox)}
                                      className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                                        isSelected 
                                          ? 'border-warehouse-orange bg-warehouse-orange/5 text-warehouse-orange font-semibold' 
                                          : 'border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-white/5 hover:border-slate-300 dark:hover:border-white/10'
                                      }`}
                                    >
                                      <span>{opt.text}</span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <div className="flex justify-end pt-4 border-t border-slate-200/50 dark:border-white/5">
                        <button 
                          onClick={handleQuizSubmit}
                          className="px-6 py-2.5 bg-warehouse-orange hover:bg-warehouse-orange/95 text-white rounded-xl font-bold text-xs shadow-md shadow-warehouse-orange/15 transition-all"
                        >
                          ส่งคำตอบตรวจข้อสอบ
                        </button>
                      </div>
                    </div>
                  ) : (
                    // Quiz Result State
                    <div className="text-center py-10 max-w-sm mx-auto space-y-6">
                      <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center ${
                        quizScore.passed ? 'bg-emerald-500/10 text-emerald-500 animate-bounce' : 'bg-rose-500/10 text-rose-500'
                      }`}>
                        {quizScore.passed ? <Award size={36} /> : <X size={36} />}
                      </div>
                      <div>
                        <h4 className="font-bold text-base text-slate-800 dark:text-white">
                          {quizScore.passed ? 'สอบผ่านเกณฑ์!' : 'สอบไม่ผ่านเกณฑ์'}
                        </h4>
                        <p className="text-slate-400 text-xs mt-2">
                          คุณทำคะแนนได้ <strong className="text-slate-800 dark:text-white font-mono text-sm">{quizScore.score}%</strong> ({quizScore.earnedPoints} จาก {quizScore.totalPoints} คะแนน)
                        </p>
                        <p className="text-[10px] text-slate-400 mt-1">เกณฑ์การสอบผ่านคือ 80% ขึ้นไป</p>
                        {quizScore.passed && quizScore.pointsAlreadyAwarded && (
                          <div className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold mt-3 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20 text-left flex items-start gap-1.5">
                            <span className="shrink-0 text-xs">⚠️</span>
                            <span>คุณทำแบบทดสอบนี้ผ่านเกณฑ์แล้วในรอบก่อนหน้า ดังนั้นคุณจะไม่ได้รับคะแนนสะสมเพิ่มในครั้งนี้เพื่อป้องกันแต้มซ้ำ</span>
                          </div>
                        )}
                        {quizScore.passed && !quizScore.pointsAlreadyAwarded && (
                          <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold mt-3 bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20 text-left flex items-start gap-1.5">
                            <span className="shrink-0 text-xs">🎉</span>
                            <span>ยินดีด้วย! คุณได้รับคะแนนสะสมเพิ่มเข้ากระเป๋าเรียบร้อยแล้ว</span>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-3 justify-center">
                        <button 
                          onClick={startQuiz}
                          className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-700 dark:text-white rounded-xl text-xs font-bold transition-all border border-slate-200/50 dark:border-white/5"
                        >
                          สอบใหม่อีกครั้ง (Retry)
                        </button>
                      </div>
                    </div>
                  )}
                </GlassCard>
              )}

              {/* Textual Instruction Card */}
              {activeLesson.body_text && activeLesson.content_type !== 'quiz' && (
                <GlassCard className="space-y-4 border border-slate-200/50 dark:border-white/5">
                  <h4 className="font-bold text-sm text-slate-800 dark:text-white">{activeLesson.title}</h4>
                  <div className="text-slate-600 dark:text-slate-300 text-xs leading-relaxed">
                    {activeLesson.body_text}
                  </div>
                  {/* Mark Completed button */}
                  <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex justify-end">
                    {activeLesson.content_type === 'video' ? (
                      <button 
                        disabled
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${
                          lessonProgress.includes(activeLesson.id)
                            ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                            : 'bg-slate-100 dark:bg-white/5 text-slate-450 dark:text-slate-400 border-slate-200 dark:border-white/5 cursor-not-allowed'
                        }`}
                      >
                        <Check size={14} />
                        <span>
                          {lessonProgress.includes(activeLesson.id) 
                            ? 'เรียนสำเร็จแล้ว (Completed)' 
                            : 'กรุณาดูวิดีโอให้จบเพื่อบันทึกการเรียน'}
                        </span>
                      </button>
                    ) : (
                      <button 
                        onClick={handleMarkComplete}
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm ${
                          lessonProgress.includes(activeLesson.id)
                            ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                            : 'bg-warehouse-orange hover:bg-warehouse-orange/95 text-white shadow-warehouse-orange/10'
                        }`}
                      >
                        <Check size={14} />
                        <span>
                          {lessonProgress.includes(activeLesson.id) 
                            ? 'เรียนสำเร็จแล้ว (Completed)' 
                            : 'ทำเครื่องหมายเรียนสำเร็จ'}
                        </span>
                      </button>
                    )}
                  </div>
                </GlassCard>
              )}

            </div>
          ) : (
            <p className="text-slate-400 text-xs text-center py-20">ไม่มีบทเรียนสำหรับการแสดงผล</p>
          )}
        </div>

      </div>

      {/* DIGITAL CERTIFICATE A4 PRINTABLE MODAL */}
      <CertificateModal
        isOpen={showCertPopup}
        onClose={() => setShowCertPopup(false)}
        certificate={{
          certificate_number: certId || `SWAN-CERT-2026-${Math.floor(100000 + Math.random() * 900000)}`,
          recipient_name: user?.name || 'พนักงานคลังสินค้า',
          employee_id: user?.employee_id || 'EMP001',
          title: course?.name || 'หลักสูตรมาตรฐานความปลอดภัยและการปฏิบัติงานคลังสินค้า Swan',
          type: 'course',
          issued_date: new Date().toISOString().split('T')[0],
          issuer_name: 'คุณประธาน  สวอนอินดัสตรีส์',
          issuer_title: 'Warehouse Operations Manager',
          skill_level: 'Level 5 Expert'
        }}
      />

      {/* 6-DIGIT OTP VERIFICATION MODAL FOR COURSE VIEWER */}
      <OTPModal
        isOpen={showOtpModal}
        onClose={() => {
          setShowOtpModal(false);
          if (!otpVerified && sessionStorage.getItem('swan_otp_verified') !== 'true') {
            router.push('/courses');
          }
        }}
        onSuccess={() => {
          setOtpVerified(true);
          setShowOtpModal(false);
        }}
        title="ยืนยันตัวตน OTP ก่อนเข้าเรียนคอร์ส อบรม"
        subtitle="กรุณายืนยันตัวตนด้วยรหัส OTP 6 หลัก เพื่อเริ่มเรียนและรับชมวิดีโอคอร์สฝึกอบรม"
        actionItemName={course?.name}
      />

      {/* SECURE FULLSCREEN PDF VIEWER MODAL */}
      {showFullscreenDoc && activeLesson && activeLesson.content_type === 'document' && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none"
          onContextMenu={(e) => e.preventDefault()}
        >
          <GlassCard className="w-full max-w-6xl h-[92vh] flex flex-col p-0 overflow-hidden border border-slate-200/50 dark:border-white/10 shadow-2xl relative" animate={false}>
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200/50 dark:border-white/5 bg-slate-100/80 dark:bg-slate-900/80">
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText size={16} className="text-amber-500 shrink-0" />
                <span className="font-bold text-xs sm:text-sm text-slate-800 dark:text-white truncate">
                  {activeLesson.title}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-md text-[9px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                  ระบบความปลอดภัย: ปิดการดาวน์โหลด / บันทึกไฟล์
                </span>
              </div>
              <button 
                onClick={() => setShowFullscreenDoc(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-2 rounded-xl bg-slate-200/50 dark:bg-white/10 transition-colors shrink-0 flex items-center gap-1 text-xs font-bold"
              >
                <X size={16} />
                <span className="hidden sm:inline">ปิดหน้าต่าง</span>
              </button>
            </div>
            
            <iframe 
              src={getSecurePdfUrl(displayDocUrl)} 
              className="w-full flex-1 border-none bg-slate-900" 
              title={activeLesson.title}
            />
          </GlassCard>
        </div>
      )}

    </div>
  );
}
