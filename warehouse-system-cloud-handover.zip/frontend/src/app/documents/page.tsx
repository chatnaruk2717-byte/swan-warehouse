'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import GlassCard from '../../components/GlassCard';
import OTPModal from '../../components/OTPModal';
import { 
  FolderOpen, 
  Plus, 
  Search, 
  Filter, 
  ChevronRight, 
  Trash2, 
  FileText, 
  Eye, 
  Upload, 
  X, 
  ExternalLink,
  Maximize2,
  Shield 
} from 'lucide-react';
import { uploadFile } from '../../utils/uploadFile';

const getSecurePdfUrl = (url: string) => {
  if (!url) return '';
  const separator = url.includes('#') ? '&' : '#';
  return `${url}${separator}toolbar=0&navpanes=0&scrollbar=0`;
};

interface WarehouseDocument {
  id: number;
  title: string;
  category: 'JD' | 'WI' | 'กฎระเบียบข้อบังคับ' | 'Kaizen' | 'OPL' | 'NearMiss' | 'แบบฟอร์มใช้คลังสินค้า';
  file_url: string;
  uploaded_by: string;
  uploaded_at: string;
}

const CATEGORIES = [
  'JD',
  'WI',
  'กฎระเบียบข้อบังคับ',
  'Kaizen',
  'OPL',
  'NearMiss',
  'แบบฟอร์มใช้คลังสินค้า'
] as const;

const defaultMockDocuments: WarehouseDocument[] = [
  {
    id: 1,
    title: 'WI-01 ขั้นตอนการปฏิบัติงานการรับสินค้าเข้าคลัง (Inbound Receiving Standard Operating Procedure)',
    category: 'WI',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'ชาติชาย ทาคำห่อ (Admin)',
    uploaded_at: '2026-07-01T08:00:00.000Z'
  },
  {
    id: 2,
    title: 'JD-04 ลักษณะงานและขอบเขตความรับผิดชอบตำแหน่งพนักงานขับรถยก (Forklift Operator Job Description)',
    category: 'JD',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'HR Manager',
    uploaded_at: '2026-07-05T09:30:00.000Z'
  },
  {
    id: 3,
    title: 'กฎระเบียบและข้อบังคับความปลอดภัยการทำงานในพื้นที่คลังสินค้า 2026 (Safety & Environment Rules)',
    category: 'กฎระเบียบข้อบังคับ',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'Safety Officer',
    uploaded_at: '2026-07-10T10:15:00.000Z'
  },
  {
    id: 4,
    title: 'Kaizen-12 การปรับปรุงพื้นที่หยิบสินค้าลดระยะเวลาการเดิน (Picking Zone Optimization)',
    category: 'Kaizen',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'Operations Sup',
    uploaded_at: '2026-07-15T14:20:00.000Z'
  },
  {
    id: 5,
    title: 'OPL-08 บทเรียนจุดเดียวเรื่องการตรวจเช็กสภาพแบตเตอรี่รถยกก่อนใช้งาน',
    category: 'OPL',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'Maintenance Team',
    uploaded_at: '2026-07-18T11:00:00.000Z'
  },
  {
    id: 6,
    title: 'แบบฟอร์มบันทึกการตรวจนับสต๊อกรายวัน (Daily Stock Counting Record Sheet)',
    category: 'แบบฟอร์มใช้คลังสินค้า',
    file_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    uploaded_by: 'Inventory Control',
    uploaded_at: '2026-07-20T16:45:00.000Z'
  }
];

export default function DocumentsPage() {
  const { api, user } = useAuth();
  const [documents, setDocuments] = useState<WarehouseDocument[]>(defaultMockDocuments);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ทั้งหมด');
  const [isLoading, setIsLoading] = useState(true);

  // OTP Verification States
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [pendingActionDoc, setPendingActionDoc] = useState<{ doc: WarehouseDocument; action: 'view' | 'download' } | null>(null);

  // Upload modal states
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    title: '',
    category: 'JD' as typeof CATEGORIES[number],
    file_url: ''
  });
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [isUploadingFile, setIsUploadingFile] = useState(false);

  // PDF Viewer modal states
  const [activeViewerDoc, setActiveViewerDoc] = useState<WarehouseDocument | null>(null);
  const [displayDocUrl, setDisplayDocUrl] = useState('');
  const [isViewerFullscreen, setIsViewerFullscreen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const handleOpenDocument = (doc: WarehouseDocument) => {
    setActiveViewerDoc(doc);

    // Record Audit Log for Security & Compliance Tracking
    try {
      const now = new Date();
      const timestampStr = now.toISOString().replace('T', ' ').substring(0, 19);
      const action = 'VIEW_DOCUMENT';
      const details = `ผู้ใช้ ${user?.name || 'พนักงาน'} (${user?.employee_id || 'EMP'}) เปิดอ่านเอกสาร "${doc.title}" (หมวดหมู่: ${doc.category})`;
      const newLog = {
        id: Date.now(),
        action,
        details,
        ip_address: '192.168.1.100',
        timestamp: timestampStr
      };
      const stored = localStorage.getItem('swan_audit_logs');
      const list = stored ? JSON.parse(stored) : [];
      list.unshift(newLog);
      localStorage.setItem('swan_audit_logs', JSON.stringify(list));

      api.post('/api/reports/audit-logs', { action, details }).catch(() => {});
    } catch (e) {}
  };

  const triggerDocumentActionWithOTP = (doc: WarehouseDocument, action: 'view' | 'download') => {
    handleOpenDocument(doc);
  };

  const handleOTPSuccess = () => {
    if (pendingActionDoc) {
      handleOpenDocument(pendingActionDoc.doc);
      setPendingActionDoc(null);
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIsMobile(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
    }
  }, []);

  useEffect(() => {
    if (activeViewerDoc && activeViewerDoc.file_url) {
      if (activeViewerDoc.file_url.startsWith('data:application/pdf')) {
        try {
          const arr = activeViewerDoc.file_url.split(',');
          const mime = arr[0].match(/:(.*?);/)?.[1] || 'application/pdf';
          const bstr = atob(arr[1]);
          let n = bstr.length;
          const u8arr = new Uint8Array(n);
          while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
          }
          const blob = new Blob([u8arr], { type: mime });
          const url = URL.createObjectURL(blob);
          setDisplayDocUrl(url);
          
          return () => {
            URL.revokeObjectURL(url);
          };
        } catch (e) {
          console.error('Failed to parse Base64 PDF to blob', e);
          setDisplayDocUrl(activeViewerDoc.file_url);
        }
      } else {
        setDisplayDocUrl(activeViewerDoc.file_url);
      }
    } else {
      setDisplayDocUrl('');
    }
  }, [activeViewerDoc]);

  // Fetch documents
  const fetchDocuments = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/api/documents');
      if (res && Array.isArray(res.data) && res.data.length > 0) {
        setDocuments(res.data);
      }
    } catch (err) {
      console.error('Failed to load documents', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  // Handle PDF file selection & upload directly to Company Storage
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        alert('กรุณาเลือกไฟล์ PDF เท่านั้น');
        return;
      }
      setUploadedFileName(file.name);
      setIsUploadingFile(true);
      try {
        const fileUrl = await uploadFile(file);
        setUploadForm(prev => ({ ...prev, file_url: fileUrl }));
      } catch (err: any) {
        console.error('Document upload error:', err);
      } finally {
        setIsUploadingFile(false);
      }
    }
  };

  // Submit new document
  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadForm.title || !uploadForm.file_url) {
      alert('กรุณากรอกข้อมูลและเลือกไฟล์ PDF ให้ครบถ้วน');
      return;
    }

    try {
      const res = await api.post('/api/documents', uploadForm);
      setDocuments(prev => [res.data, ...(Array.isArray(prev) ? prev : [])]);
      setShowUploadModal(false);
      setUploadForm({ title: '', category: 'JD', file_url: '' });
      setUploadedFileName('');
      alert('อัปโหลดเอกสารสำเร็จเรียบร้อย');
    } catch (err) {
      // Mock Fallback
      const mockDoc: WarehouseDocument = {
        id: Date.now(),
        title: uploadForm.title,
        category: uploadForm.category,
        file_url: uploadForm.file_url,
        uploaded_by: user?.name || 'Staff',
        uploaded_at: new Date().toISOString()
      };
      setDocuments(prev => [mockDoc, ...(Array.isArray(prev) ? prev : [])]);
      setShowUploadModal(false);
      setUploadForm({ title: '', category: 'JD', file_url: '' });
      setUploadedFileName('');
      alert('อัปโหลดเอกสารสำเร็จเรียบร้อย');
    }
  };

  // Delete document
  const handleDeleteDocument = async (id: number) => {
    if (!confirm('คุณแน่ใจหรือไม่ว่าต้องการลบเอกสารฉบับนี้?')) return;
    try {
      await api.delete(`/api/documents/${id}`);
      setDocuments(prev => (Array.isArray(prev) ? prev.filter(d => d.id !== id) : []));
      alert('ลบเอกสารเสร็จสิ้น');
    } catch (err) {
      setDocuments(prev => (Array.isArray(prev) ? prev.filter(d => d.id !== id) : []));
      alert('ลบเอกสารเสร็จสิ้น');
    }
  };

  // Filter documents safely
  const docList = Array.isArray(documents) ? documents : defaultMockDocuments;
  const filteredDocs = docList.filter(doc => {
    if (!doc || !doc.title) return false;
    const matchesSearch = doc.title.toLowerCase().includes((searchQuery || '').toLowerCase()) || 
                          (doc.category || '').toLowerCase().includes((searchQuery || '').toLowerCase());
    const matchesCategory = selectedCategory === 'ทั้งหมด' || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8 p-1 sm:p-2">
      
      {/* Top Banner Header */}
      <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-warehouse-navy to-indigo-950 p-8 sm:p-10 border border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(249,115,22,0.12),transparent_45%)]" />
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-3">
              <FolderOpen className="text-warehouse-orange animate-pulse" size={28} />
              เอกสารคลังสินค้า
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm font-medium">
              คลังเก็บแผนผัง วิธีปฏิบัติงาน ใบกติกาข้อบังคับทั่วไป และแบบฟอร์มคลังสินค้าเพื่อความโปร่งใส ปลอดภัย และมีมาตรฐาน
            </p>
          </div>

          {/* Action Trigger button for upload (Admin and Staff only) */}
          {user && ['admin', 'staff'].includes(user.role) && (
            <button
              onClick={() => setShowUploadModal(true)}
              className="px-6 py-3.5 bg-gradient-to-r from-warehouse-orange to-amber-500 hover:from-warehouse-orange hover:to-amber-600 text-white rounded-2xl font-bold text-xs shadow-lg shadow-warehouse-orange/20 transition-all flex items-center justify-center gap-2"
            >
              <Plus size={16} />
              อัปโหลดเอกสารใหม่
            </button>
          )}
        </div>
      </div>

      {/* Control Area: Search and Category Pills */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Sidebar Filters */}
        <div className="lg:col-span-1 space-y-5">
          {/* Search Card */}
          <GlassCard className="p-5 border border-slate-200/50 dark:border-white/5 space-y-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 text-slate-400" size={16} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ค้นหาชื่อเอกสาร..."
                className="w-full pl-10 pr-4 py-3 bg-slate-100/50 dark:bg-slate-900/50 border border-slate-200/50 dark:border-white/5 rounded-2xl text-xs focus:outline-none focus:border-warehouse-orange transition-colors"
              />
            </div>
            
            <div className="flex items-center gap-2 text-slate-400 text-[10px] uppercase font-bold tracking-wider px-1">
              <Filter size={12} />
              <span>หมวดหมู่เอกสาร</span>
            </div>

            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => setSelectedCategory('ทั้งหมด')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs transition-colors flex items-center justify-between ${
                  selectedCategory === 'ทั้งหมด'
                    ? 'bg-warehouse-orange/15 text-warehouse-orange font-bold border border-warehouse-orange/20'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 border border-transparent'
                }`}
              >
                <span>ทั้งหมด</span>
                <ChevronRight size={12} className={selectedCategory === 'ทั้งหมด' ? 'opacity-100' : 'opacity-40'} />
              </button>

              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs transition-colors flex items-center justify-between ${
                    selectedCategory === cat
                      ? 'bg-warehouse-orange/15 text-warehouse-orange font-bold border border-warehouse-orange/20'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <span className="truncate pr-2">{cat}</span>
                  <ChevronRight size={12} className={selectedCategory === cat ? 'opacity-100' : 'opacity-40'} />
                </button>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Main Document Listing Grid */}
        <div className="lg:col-span-3 space-y-6">
          {isLoading ? (
            <div className="text-center py-20">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-warehouse-orange mx-auto"></div>
              <p className="text-slate-400 text-xs mt-4">กำลังดึงข้อมูลเอกสาร...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredDocs.map((doc) => (
                  <GlassCard key={doc.id} className="p-5 border border-slate-200/50 dark:border-white/5 flex flex-col justify-between hover:border-warehouse-orange/30 transition-all duration-300">
                    <div className="space-y-3.5">
                      {/* Top Metadata */}
                      <div className="flex items-center justify-between gap-3">
                        <span className={`px-2.5 py-1 rounded-lg text-[9px] font-extrabold uppercase ${
                          doc.category === 'JD' ? 'bg-indigo-500/10 text-indigo-500 border border-indigo-500/20' :
                          doc.category === 'WI' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' :
                          doc.category === 'กฎระเบียบข้อบังคับ' ? 'bg-rose-500/10 text-rose-500 border border-rose-500/20' :
                          doc.category === 'Kaizen' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' :
                          doc.category === 'OPL' ? 'bg-teal-500/10 text-teal-500 border border-teal-500/20' :
                          doc.category === 'NearMiss' ? 'bg-orange-500/10 text-orange-500 border border-orange-500/20' :
                          'bg-purple-500/10 text-purple-500 border border-purple-500/20'
                        }`}>
                          {doc.category}
                        </span>
                        
                        {/* Delete button (Admin and Staff only) */}
                        {user && ['admin', 'staff'].includes(user.role) && (
                          <button
                            onClick={() => handleDeleteDocument(doc.id)}
                            className="text-rose-500 hover:text-rose-400 transition-colors p-1"
                            title="ลบเอกสาร"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>

                      {/* Title & Document Preview info */}
                      <div className="space-y-1.5 min-w-0">
                        <h4 className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm line-clamp-2 leading-snug flex items-start gap-2">
                          <FileText className="text-slate-400 shrink-0 mt-0.5" size={16} />
                          <span>{doc.title}</span>
                        </h4>
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium">
                          <span>อัปโหลดโดย: {doc.uploaded_by}</span>
                          <span>•</span>
                          <span>{new Date(doc.uploaded_at).toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' })}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action button - Read Online Only */}
                    <div className="mt-5 border-t border-slate-100 dark:border-white/5 pt-4">
                      <button
                        onClick={() => handleOpenDocument(doc)}
                        className="w-full py-2.5 bg-emerald-600/90 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-900/20 flex items-center justify-center gap-2"
                      >
                        <Eye size={14} />
                        <span>เปิดอ่านออนไลน์</span>
                      </button>
                    </div>
                  </GlassCard>
                ))}
              </div>

              {filteredDocs.length === 0 && (
                <div className="text-center py-20 bg-slate-50 dark:bg-white/5 rounded-3xl border border-slate-200/50 dark:border-white/5">
                  <FileText className="mx-auto text-slate-400 mb-3" size={36} />
                  <p className="text-slate-400 text-xs">ไม่พบเอกสารตรงตามเงื่อนไขการค้นหาของคุณ</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* UPLOAD DOCUMENT MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-md overflow-hidden border border-white/10" animate={false}>
            <div className="flex items-center justify-between pb-4 border-b border-slate-200/50 dark:border-white/5 mb-6">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Upload size={18} className="text-warehouse-orange" />
                อัปโหลดเอกสารใหม่
              </h3>
              <button 
                onClick={() => { setShowUploadModal(false); setUploadedFileName(''); }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ชื่อหัวข้อเอกสาร</label>
                <input
                  type="text"
                  required
                  value={uploadForm.title}
                  onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                  placeholder="ตัวอย่างเช่น WI-04 ขั้นตอนสวมใส่อุปกรณ์ป้องกันภัย..."
                  className="w-full glass-input text-xs py-2.5 px-3.5"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">หมวดหมู่เอกสาร</label>
                <select
                  value={uploadForm.category}
                  onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value as typeof CATEGORIES[number] })}
                  className="w-full glass-input text-xs py-2.5 px-3 bg-white dark:bg-warehouse-slate"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ไฟล์เอกสาร PDF</label>
                <div className="w-full">
                  <label className="flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-white/15 hover:border-warehouse-orange hover:dark:border-warehouse-orange rounded-2xl p-6 cursor-pointer transition-all bg-white/50 dark:bg-warehouse-slate/20">
                    <div className="text-center space-y-2">
                      <Upload size={24} className="mx-auto text-slate-400 animate-bounce" />
                      <p className="text-xs text-slate-400 font-semibold">
                        {isUploadingFile ? 'กำลังเข้ารหัสไฟล์...' : uploadedFileName ? `ไฟล์ที่เลือก: ${uploadedFileName}` : 'คลิกเพื่อเลือกไฟล์ PDF'}
                      </p>
                      <p className="text-[9px] text-slate-500">จำกัดเฉพาะไฟล์ .pdf เท่านั้น</p>
                    </div>
                    <input
                      type="file"
                      accept="application/pdf"
                      className="hidden"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-200/50 dark:border-white/5 mt-6">
                <button
                  type="button"
                  onClick={() => { setShowUploadModal(false); setUploadedFileName(''); }}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-700 dark:text-white rounded-xl text-xs font-bold transition-all border border-slate-200/50 dark:border-white/5"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isUploadingFile || !uploadForm.file_url}
                  className="flex-1 py-2.5 bg-warehouse-orange text-white rounded-xl text-xs font-bold transition-all hover:bg-warehouse-orange/95 disabled:bg-slate-400 disabled:cursor-not-allowed shadow-md shadow-warehouse-orange/10"
                >
                  {isUploadingFile ? 'กรุณารอไฟล์...' : 'บันทึกเอกสาร'}
                </button>
              </div>
            </form>
          </GlassCard>
        </div>
      )}

      {/* PDF INLINE VIEWER MODAL */}
      {activeViewerDoc && (
        <div 
          className="fixed inset-0 bg-slate-900/85 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 select-none"
          onContextMenu={(e) => e.preventDefault()}
        >
          <GlassCard 
            className={`w-full flex flex-col p-0 overflow-hidden border border-white/10 shadow-2xl transition-all duration-200 ${
              isViewerFullscreen ? 'max-w-full h-full rounded-none' : 'max-w-5xl h-[88vh] rounded-3xl'
            }`} 
            animate={false}
          >
            {/* Header info */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200/50 dark:border-white/5 bg-slate-100/80 dark:bg-slate-900/80 flex-shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="px-2.5 py-0.5 rounded-lg text-[9px] font-extrabold uppercase bg-warehouse-orange/15 text-warehouse-orange border border-warehouse-orange/20 shrink-0">
                  {activeViewerDoc.category}
                </span>
                <span className="font-bold text-xs sm:text-sm text-slate-800 dark:text-white truncate">
                  {activeViewerDoc.title}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-md text-[9px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20 shrink-0">
                  ระบบอ่านออนไลน์ (ห้ามดาวน์โหลด/บันทึกไฟล์)
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => setIsViewerFullscreen(!isViewerFullscreen)}
                  className="text-slate-600 dark:text-slate-300 hover:text-warehouse-orange dark:hover:text-warehouse-orange p-1.5 rounded-lg bg-slate-200/50 dark:bg-white/5 transition-colors flex items-center gap-1 text-xs font-semibold"
                  title={isViewerFullscreen ? "ย่อหน้าต่าง" : "ขยายเต็มจอ"}
                >
                  <Maximize2 size={14} />
                  <span className="hidden sm:inline">{isViewerFullscreen ? "ย่อขนาด" : "ขยายเต็มจอ"}</span>
                </button>
                <button 
                  onClick={() => {
                    setActiveViewerDoc(null);
                    setIsViewerFullscreen(false);
                  }}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1.5 rounded-lg bg-slate-200/50 dark:bg-white/5 transition-colors shrink-0"
                  title="ปิด"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
            
            {/* Embedded PDF iframe */}
            <iframe 
              src={getSecurePdfUrl(displayDocUrl)} 
              className="w-full flex-1 border-none bg-slate-900" 
              title={activeViewerDoc.title}
            />
          </GlassCard>
        </div>
      )}

      {/* 6-DIGIT OTP VERIFICATION MODAL FOR DOCUMENTS */}
      <OTPModal
        isOpen={showOtpModal}
        onClose={() => { setShowOtpModal(false); setPendingActionDoc(null); }}
        onSuccess={handleOTPSuccess}
        title="ยืนยันตัวตน OTP ก่อนเปิดอ่านเอกสาร"
        subtitle="กรุณายืนยันตัวตนด้วยรหัส OTP 6 หลัก เพื่อความปลอดภัยในการเข้าถึงเอกสารคลังสินค้า"
        actionItemName={pendingActionDoc?.doc.title}
      />

    </div>
  );
}
